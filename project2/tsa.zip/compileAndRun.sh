#!/bin/bash
#Simple compilation and execution of project using relative paths
#Author: Justin Peterson

#Compile
cd source
javac Main.java

#Run
java Main
