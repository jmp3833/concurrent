class ScanBodyRequest {
    Passenger p;
    public ScanBodyRequest(Passenger p){
        this.p = p;
    }
}
