public class NewPassengerRequest {
    Passenger p;

    public NewPassengerRequest(Passenger p) {
        this.p = p;
    }
}
