class SendToLineRequest {

}
