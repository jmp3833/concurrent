public class BodyScannedRequest {
    Passenger p;
    boolean passed;

    public BodyScannedRequest(Passenger p, boolean passed) {
        this.p = p;
        this.passed = passed;
    }
}
