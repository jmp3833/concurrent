class AddToLineRequest {
  public Passenger p;

  public AddToLineRequest(Passenger p) {
    this.p = p; 
  }

  public Passenger getPassenger() {
    return this.p; 
  }
}
