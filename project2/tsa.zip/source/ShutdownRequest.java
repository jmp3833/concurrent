class ShutdownRequest {

}
