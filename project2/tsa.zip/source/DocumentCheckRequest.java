class DocumentCheckRequest {
    private Passenger p;

    public DocumentCheckRequest(Passenger p) {
      this.p = p; 
    }

    public Passenger getPassenger() {
      return this.p; 
    }
}
