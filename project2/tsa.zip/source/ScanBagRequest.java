class ScanBagRequest {
    Bag b;
    public ScanBagRequest(Bag b){
        this.b = b;
    }
}
