public class AddPrisonerRequest {
    Passenger p;

    public AddPrisonerRequest(Passenger p) {
        this.p = p;
    }
}
